<?php
$host = "localhost";
$user = "root"; // Default MySQL user
$password = ""; // Default password is empty
$dbname = "student_grades";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
