<?php
header("Content-Type: application/json");
include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method == "POST" && isset($_POST['name'])) {
    $name = $_POST['name'];
    $midterm = $_POST['midterm_score'];
    $final = $_POST['final_score'];

    $sql = "INSERT INTO students (name, midterm_score, final_score) VALUES ('$name', $midterm, $final)";
    echo json_encode(["message" => $conn->query($sql) ? "Student added successfully" : "Error"]);
}

if ($method == "GET" && !isset($_GET['id'])) {
    $result = $conn->query("SELECT * FROM students");
    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
}

if ($method == "GET" && isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM students WHERE id=$id");
    echo json_encode($result->fetch_assoc());
}

if ($method == "PUT") {
    // Parse raw input
    parse_str(file_get_contents("php://input"), $_PUT);

    // Check if values are set to prevent "Undefined array key" error
    if (!isset($_PUT['id']) || !isset($_PUT['midterm_score']) || !isset($_PUT['final_score'])) {
        echo json_encode(["error" => "Missing required fields"]);
        exit;
    }

    // Get the values safely
    $id = intval($_PUT['id']);
    $midterm = intval($_PUT['midterm_score']);
    $final = intval($_PUT['final_score']);

    // Ensure valid values before updating
    if ($id > 0 && $midterm >= 0 && $final >= 0) {
        $sql = "UPDATE students SET midterm_score=$midterm, final_score=$final WHERE id=$id";
        echo json_encode(["message" => $conn->query($sql) ? "Student updated successfully" : "Error"]);
    } else {
        echo json_encode(["error" => "Invalid data"]);
    }
}


if ($method == "DELETE") {
    parse_str(file_get_contents("php://input"), $_DELETE);
    $id = $_DELETE['id'];

    $sql = "DELETE FROM students WHERE id=$id";
    echo json_encode(["message" => $conn->query($sql) ? "Student deleted successfully" : "Error"]);
}

$conn->close();
?>
