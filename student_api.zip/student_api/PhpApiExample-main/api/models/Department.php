<?php

class Department {
    public $Id;
    public $Name;
}