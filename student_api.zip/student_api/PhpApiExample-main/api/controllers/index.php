<?php
header("Content-Type: application/json");
include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

// ✅ 1. Add a Student
if ($method == "POST" && isset($_POST['name'])) {
    $name = $_POST['name'];
    $midterm = $_POST['midterm_score'];
    $final = $_POST['final_score'];

    $sql = "INSERT INTO students (name, midterm_score, final_score) VALUES ('$name', $midterm, $final)";
    echo json_encode(["message" => $conn->query($sql) ? "Student added successfully" : "Error"]);
}

// ✅ 2. Retrieve All Students
if ($method == "GET" && !isset($_GET['id'])) {
    $result = $conn->query("SELECT * FROM students");
    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
}

// ✅ 3. Retrieve Single Student
if ($method == "GET" && isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM students WHERE id=$id");
    echo json_encode($result->fetch_assoc());
}

// ✅ 4. Update Student Scores
if ($method == "PUT") {
    parse_str(file_get_contents("php://input"), $_PUT);
    $id = $_PUT['id'];
    $midterm = $_PUT['midterm_score'];
    $final = $_PUT['final_score'];

    $sql = "UPDATE students SET midterm_score=$midterm, final_score=$final WHERE id=$id";
    echo json_encode(["message" => $conn->query($sql) ? "Student updated successfully" : "Error"]);
}

// ✅ 5. Delete a Student
if ($method == "DELETE") {
    parse_str(file_get_contents("php://input"), $_DELETE);
    $id = $_DELETE['id'];

    $sql = "DELETE FROM students WHERE id=$id";
    echo json_encode(["message" => $conn->query($sql) ? "Student deleted successfully" : "Error"]);
}

$conn->close();
?>
